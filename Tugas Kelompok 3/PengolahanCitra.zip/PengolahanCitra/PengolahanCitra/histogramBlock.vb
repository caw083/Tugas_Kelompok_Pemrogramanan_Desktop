﻿Public Class histogramBlock
    Private Sub frmHistogram_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim r, g, b, max As Integer
        Dim hR(11), hG(11), hB(11) As Integer
        Dim bmp = New Bitmap(Form1.PictureBox1.Image)
        Dim frekR(11), frekG(11), frekB(11) As Integer

        For i As Integer = 0 To 11
            frekR(i) = 0
            frekG(i) = 0
            frekB(i) = 0
        Next

        Dim interval As Integer = 256 \ 6 ' Divide the 256 color range into 6 intervals for each color channel

        For bar As Integer = 0 To Form1.PictureBox1.Image.Height - 1
            For kol As Integer = 0 To Form1.PictureBox1.Image.Width - 1
                r = bmp.GetPixel(kol, bar).R
                g = bmp.GetPixel(kol, bar).G
                b = bmp.GetPixel(kol, bar).B

                ' Ensure that color values are within the range of 0 to 255
                r = Math.Max(0, Math.Min(r, 255))
                g = Math.Max(0, Math.Min(g, 255))
                b = Math.Max(0, Math.Min(b, 255))

                ' Calculate the indices for each channel
                Dim redIndex As Integer = r \ interval
                Dim greenIndex As Integer = g \ interval
                Dim blueIndex As Integer = b \ interval

                ' Increment the corresponding interval count for each channel
                If redIndex >= 0 AndAlso redIndex < frekR.Length Then
                    frekR(redIndex) += 1
                End If
                If greenIndex >= 0 AndAlso greenIndex < frekG.Length Then
                    frekG(greenIndex) += 1
                End If
                If blueIndex >= 0 AndAlso blueIndex < frekB.Length Then
                    frekB(blueIndex) += 1
                End If
            Next
        Next

        Dim histo = New Bitmap(200, 60)

        ' Find the maximum count among all channels
        max = Math.Max(frekR.Max, Math.Max(frekG.Max, frekB.Max))

        For i As Integer = 0 To 11
            hR(i) = Math.Round(frekR(i) / max * 199)
            hG(i) = Math.Round(frekG(i) / max * 199)
            hB(i) = Math.Round(frekB(i) / max * 199)
        Next

        Dim gr As Graphics = Graphics.FromImage(histo)

        Dim barDistance As Integer = 20 ' Distance between bars
        Dim channelDistance As Integer = 10 ' Distance between channels

        For i As Integer = 0 To 11
            ' Draw bars for red channel
            Dim yR As Integer = 50 - hR(i) ' Starting y-value for the rectangle
            gr.FillRectangle(Brushes.Red, New Rectangle(3 + (i * (20 + barDistance) + channelDistance * 0), yR, 10, hR(i)))

            ' Draw bars for green channel
            Dim yG As Integer = 50 - hG(i) ' Starting y-value for the rectangle
            gr.FillRectangle(Brushes.Green, New Rectangle(3 + ((i * (20 + barDistance)) + 5 + channelDistance * 1), yG, 20, hG(i)))

            ' Draw bars for blue channel
            Dim yB As Integer = 50 - hB(i) ' Starting y-value for the rectangle
            gr.FillRectangle(Brushes.Blue, New Rectangle(3 + ((i * (20 + barDistance)) + 10 + channelDistance * 2), yB, 20, hB(i)))
        Next




        PictureBox1.Image = histo
    End Sub

    Private Sub btnTutup_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
